export default function Page() {
  return <h1>Veikia — Next 15</h1>
}
