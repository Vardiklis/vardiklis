export const metadata = { title: 'Testas' }

export default function RootLayout({ children }) {
  return (
    <html lang="lt">
      <body>{children}</body>
    </html>
  )
}
