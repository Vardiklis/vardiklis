export default function Page() {
  return <h1>Veikia — Next 16</h1>
}
